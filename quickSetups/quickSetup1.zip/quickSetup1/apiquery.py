#======================================================================================================================================================
# Description: This script creates a custom excel file containing useful necdf file metadata per line (i.e opendap url, file name, variables within it etc)
#              for a given SOCIB platform type and according to some selection criterias and using SOCIB API
# Contact: protllan@socib.es
# Requierements: 
#   1) To run in a python environment with requests, pandas and json modules installed
#   2) settings/*querysettings*.py
#======================================================================================================================================================

#SETTINGS
from  settings.querysettings import *

#PACKAGES
import requests
import json
import pandas
import os
import urllib.parse as urlparse
from urllib.parse import parse_qs

#AUXILIARY FUNCTIONS
def cleanQueryParams(url):
    #remove empty param values form query
    parsed = urlparse.urlparse(url)
    paramPairs = parse_qs(parsed.query)
    _url = url.split('?')[0]+'?'
    for key,val in paramPairs.items():
        _url = _url+key+'='+val[0]+'&'
    return _url

def instrument_details(data, apiCache):
    #it handles the implicit info retourned as value for the intrument; in particular, it will return its name, type and category
    url = data['instrument']
    if url != None:
        #instrument name
        try:
            response = apiCache[url]
        except:
            request = requests.get(url, headers=headers)
            apiCache[url] = json.loads(request.text)
            response = apiCache[url]
        data['instrument_name'] = response['name']
        #instrument type and category
        url = response['type']
        try:
            response = apiCache[url]
        except:
            request = requests.get(url, headers=headers)
            apiCache[url] = json.loads(request.text)
            response = apiCache[url]
        data['instrument_type'] = response['name']
        data['instrument_category'] = response['type']
    else: #aggregations case
        data['instrument_name'] = 'N/A'
        data['instrument_type'] = 'N/A'
        data['instrument_category'] = 'N/A'
    return [data,apiCache]

def variables_details(data, apiCache):
    #it handles the implicit info returned as value for the parameters; in particular it will return its name and its corresponding std variable code.
    url = data['variables']
    data['variables'] = ''
    try:
        response = apiCache[url]
    except:
        request = requests.get(url, headers=headers)
        apiCache[url] = json.loads(request.text)
        response = apiCache[url]
    for parameter in [param for param in response if param['standard_variable'] != None]:
        url = parameter['standard_variable']
        try:
            response = apiCache[url]
        except:
            request = requests.get(url, headers=headers)
            apiCache[url] = json.loads(request.text)
            response = apiCache[url]
        try:
            data['variables'] = data['variables'] +','+ response['code'] +' ('+parameter['name']+')'
        except:
            pass
    return [data, apiCache]


##QUERY 1 - QUERY LIKE "GIVE ME ALL PLATFORMS MATCHING THE ABOVE TYPE"
end_point = '/platforms/'
query_parameters = 'platform_type='+platform_type
platforms_id = []
url = '%s%s?%s' % (api_url, end_point, query_parameters)
while url != None:
    print(url)
    request = requests.get(url, headers=headers)
    response = json.loads(request.text)
    for platform in response['results']:#loop over netCDFs (entries)
        platforms_id.append(platform['id'])
    url = response['next']

##QUERY 2 - QUERY LIKE "FROM ABOVE PLATFORMS (identified by its id) GIVE ME THE LIST OF NETCDFS THAT REPORTED DATA BETWEEN CERTAIN DATES, WITHIN A SPECIFIC AREA ETC"
#There are more query parameters: see in the documentation: http://api.socib.es/beta/#/entries/entries_retrieve
end_point = '/entries/'
query_parameters = 'processing_level='+processing_level+'&initial_datetime='+initial_datetime+'&end_datetime='+end_datetime+'&standard_variable='+standard_variable+'&data_mode='+data_mode+'&bbox='+bbox+'&instrument_type='+instrument_type
entries = []
for platform_id in platforms_id: 
    url = '%s%s?%s&platform=%s' % (api_url, end_point, query_parameters, platform_id)
    url = cleanQueryParams(url)
    while url != None:
        print(url)
        request_ = requests.get(url, headers=headers)
        response_ = json.loads(request_.text)
        for entry in response_['results']:#loop over netCDFs (entries)
            data = {}
            data['platform_id'] = platform_id
            #inherited info
            data['id'] = entry['id']
            data['processing_level'] = entry['processing_level']
            data['data_mode'] = entry['data_mode']
            data['initial_datetime'] = entry['initial_datetime']
            data['end_datetime'] = entry['end_datetime']
            data['opendap_url'] = entry['services']['opendap']['url']
            data['http_url'] = entry['services']['http_file']['url']
            data['catalog_url'] = entry['services']['thredds_catalog']['url']
            data['variables'] = entry['parameters']
            data['instrument'] = entry['instrument']
            #derived info
            data['netCDF_name'] = entry['services']['opendap']['url'].split('/')[-1]
            #implicit info
            data, apiCache = variables_details(data,apiCache) #variables handler
            data, apiCache = instrument_details(data,apiCache) #instrument handler
            entries.append(data)
        url = response_['next']

#EXPORTING THE FULL LIST TO A EXCELL FILE -> ordering the ouput by date, instrument type, instrument name and processing level
if ouput_dir == '':
    output_dir = os.getcwd()
if len(entries)>0:
    nc_dataframe = pandas.DataFrame.from_dict(entries).sort_values(ordered_header)
    with pandas.ExcelWriter(os.path.join(ouput_dir, outputed_file_name)) as writer:  
        for platform, platform_group in nc_dataframe.groupby(['platform_id']):
            platform_group[ordered_header].to_excel(writer, sheet_name=platform)
else:
    print('No mathing results. Please review your querysettings.')