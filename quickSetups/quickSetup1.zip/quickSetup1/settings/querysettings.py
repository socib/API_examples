#======================================================================================================================================================
# Description: api query settings
# Contact: protllan@socib.es
# Requirements: 
#           1) Update your api_key  in #SOCIB API SETTINGS section
#           2) Update the #QUERY SETTINGS section with the values suitable for you; some examples given
#           3) Update the #OUTPUT SETTINGS section with the values suitable for you; some examples given
#
#======================================================================================================================================================

#SOCIB API SETTINGS
api_key = 'api_dummy' #write your SOCIB api_key => get it from http://api.socib.es/home/ (formulary at the bottom of the page)
api_url = 'http://api.socib.es'
headers = {
    'accept': 'application/vnd.socib+json',
    'apikey': api_key,
}
apiCache = {}

#QUERY SETTINGS
#PLATFORM TYPE IS THE ONLY MANDATORY FIELD; THE REST CAN BE SET AS AN EMPTY STRING ''
##Qualitative
platform_type = 'Research Vessel'#check for more ids at: http://api.socib.es/platform-types/?api_key=api_dummy
instrument_type = 'CTD' #check for more ids at: http://api.socib.es/instrument-types/?api_key=api_dummy
data_mode = '' ## check for more data modes at: http://api.socib.es/data-modes/?api_key=api_dummy
processing_level = '' #check for more processing variables at: http://api.socib.es/processing-levels/?api_key=api_dummy
standard_name = ''#check for more variables at: http://api.socib.es/standard-variables/?api_key=api_dummy
##Quantitative
bbox = '37.6,40.6,-1.06,6.3' #min. lat., max. lat., min. lon., max. lon
initial_datetime = '2016-01-01T00:00:00'
end_datetime = '2018-01-01T00:00:00'

#OUTPUT SETTINGS
ouput_dir = '' #Set a path for the excel file outputed. If none is given the default output dir will be the current working directory
outputed_file_name = 'scb-files.xlsx'#Set a name for the excel file outputed. By default: scb-files.xlsx
ordered_header = ['instrument_category', 'instrument_type', 'instrument_name', 'processing_level', 'data_mode', 'initial_datetime', 'end_datetime', 'variables', 'netCDF_name', 'id', 'opendap_url', 'http_url', 'catalog_url']#Set a different order in the headers if preferred