"""
This package only includes the settings for seaboard project. 
All the python/django code for this application is in seawidgets package.

There is an important part of the logic of the widgets written in Javascript, inside static/widgets folder.

"""