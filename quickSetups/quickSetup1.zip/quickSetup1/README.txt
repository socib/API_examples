Contact: protllan@socib.es

Description: 

	a) apiqueryquery.py script creates a custom excel file containing useful necdf file metadata per line (i.e opendap url, file name, variables within it etc) from a given SOCIB platform type and other specifications stated in settings/*querysettings*.py script.

	b) settings/*querysettings*.py script contains the information required by the above script to run: 
		* user api token -> get it from http://api.socib.es/home/ (formulary at the bottom of the page)
		* platform_type to search + other specifications
		* output name + output dir

Usage:
	1) Install python => https://www.python.org/downloads/
	2) Install the following packages: requests, json, pandas
	3) Update the information in querysettings.py according to your needs
	4) Run on terminal: python apiquery.py (or the full path to the file apiquery.py)
